<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	
		<title>Suresh Khattri</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="css/animate.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/portfolio-style.css">
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.singlePageNav.min.js"></script>
		<script src="js/typed.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/custom.js"></script>

  

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

        <!-- start header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <p><i class="fa fa-phone"></i><span> Phone</span>9867705270</p>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <p><i class="fa fa-envelope-o"></i><span> Email</span><a href="index.html">sureshkhattri999@gmail.com</a></p>
                    </div>
                    <div class="col-md-5 col-sm-4 col-xs-12">
                        <ul class="social-icon">
                            <li><span>Keep in touch..</span></li>
                            <li><a href="https://www.facebook.com/profile.php?id=100010087509998" class="fa fa-facebook" target="_blank"></a></li>
                            <li><a href="https://twitter.com/SureshKhattri" class="fa fa-twitter" target="_blank"></a></li>
                            <li><a href="https://www.instagram.com/surfacedada/" class="fa fa-instagram"target="_blank"></a></li>
                            <li><a href="https://github.com/virussuresh" class="fa fa-github"target="_blank"></a></li>
                            <li><a href="https://www.linkedin.com/in/suresh-khattri-43693b140/" class="fa fa-linkedin"target="_blank"></a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->

    	<!-- start navigation -->
		<nav class="navbar navbar-default portfolio-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="index.html" class="navbar-brand">Web Designer</a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#top">HOME</a></li>
						<li><a href="#about">ABOUT</a></li>
						<li><a href="#team">OTHER ACTIVITIES</a></li>
						<li><a href="#service">SERVICES</a></li>
						<li><a href="#portfolio">PORTFOLIO</a></li>
						<li><a href="#contact">CONTACT</a></li>
                        <li><a href="https://app.moqups.com/sumeghtravels@gmail.com/cVLY6xTUDH/view" target="_blank">View Mockup Design</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- end navigation -->

    	<!-- start home -->
    	<section id="home">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-offset-2 col-md-8">
    					<h1 class="wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">I Develop <span>Web Application</span></h1>
    					<div class="element">
                            <div class="sub-element">Hello, It's me Suresh Khattri</div>
                            <div class="sub-element">People expect good service but few are willing to give it.</div>
                            <div class="sub-element">Our attitude towards others determines their attitude towards us.</div>
                        </div>
    					<a data-scroll href="#about" class="btn btn-default wow fadeInUp" data-wow-offset="50" data-wow-delay="0.6s">GET STARTED</a>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end home -->

    	<!-- start about -->
		<section id="about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">Why <span>ME</span></h2>
    				</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.6s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-mobile"></i>
								</div>
								<h3 class="media-heading">Constantly Learning and Improving</h3>
							</div>
							<div class="media-body">
								<p>Never stop learning <a rel="nofollow" href="http://www.sureshkhattri.com.np" target="_parent">Technologies.</a> In a fast moving industry, staying on top of your game means you never stop learning. Technologies change just as fast as trends, and what’s common practice now might already be outdated in a few years. If you want to become a great web developer, you have to stay ahead of the curve. That means learning new technologies and programming languages and also keeping an eye on what customers want (and need) in order to stay satisfied.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-offset="50" data-wow-delay="0.9s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-comment-o"></i>
								</div>
								<h3 class="media-heading">Determination</h3>
							</div>
							<div class="media-body">
								<p>A number of IT projects stall because of a variety of issues:financial problems, issues with vendors, problems with software, hardware or processes, a lack of teamwork, or one of many other reasons.It is important for an IT professional to stay focused on the ultimate goal and continue to work toward that result. Beginning a project with a clear and realistic timeline and budget can help you achieve your ultimate goal. Your employer will be impressed with your ability not only to plan a project, but also to see it through to completion.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
						<div class="media">
							<div class="media-heading-wrapper">
								<div class="media-object pull-left">
									<i class="fa fa-html5"></i>
								</div>
								<h3 class="media-heading">Leadership</h3>
							</div>
							<div class="media-body">
								<p>Even if you are not in a management position, you will often be asked to manage a project or team, if only for a brief period. Being a project manager requires strong communication skills, the ability to delegate tasks, and a constant focus on the end goal. As an IT professional, you may also be involved in client and vendor management. It is essential that you know how to communicate with clients and vendors effectively to ensure your company's needs are being met efficiently.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- end about -->

    	<!-- start team -->
    	<section id="team">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>OTHER</span> ACTIVITIES</h2>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/nepaltelecom.jpg" class="img-responsive" alt="Nepal Telecome 1">
    							<div class="team-des">
    								<h4>Nepal Telecom</h4>
    								<span>Internship</span>
    								<p>Form JUN 2017 to DEC 2017</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/tourismboard.jpg" class="img-responsive" alt="tourismboard 2">
    							<div class="team-des">
    								<h4>Nepal Tourism Board</h4>
    								<span>VideoGrapher</span>
    								<p>I have a passion for photography! I really love a life of being creative…
                                    </p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.3s">
    					<div class="team-wrapper">
    						<img src="images/internationalstudent.jpg" class="img-responsive" alt="internationalstudent 3">
    							<div class="team-des">
    								<h4>South London Academy</h4>
    								<span>International Student</span>
    								<p>While student of South London Academy for Short team as an Internation Student. Receiving Certificate of Complation</p>
    							</div>
    					</div>
    				</div>
    				<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="1.6s">
    					<div class="team-wrapper">
    						<img src="images/traveller.jpg" class="img-responsive" alt="traveller 4">
    							<div class="team-des">
    								<h4>Tower Bridge London</h4>
    								<span>Visitor</span>
    								<p>Summer School London 2018</p>
    							</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end team -->

    	<!-- start service -->
    	<section id="service">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">SKILLS <span> & </span>SERVICES</h2>
    				</div>
    				<div class="col-md-4 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
    					<i class="fa fa-laptop"></i>
    					<h4>Inbound and Digital Marketing Strategist</h4>
    					<p><b>Search Engine & Social Media Optimization Expert</b>
                        Digital marketing is the way ahead. Keeping up with the times and with the way digital trends have conquered the lifestyle of people, digital marketing is the future. This includes, among other things, using the internet to advertise about your presence which will subsequently increase the sales of the items you are offering, be it goods or services. The changing times has also added mobile as the main device that people use most frequently. Adapting the offerings, like the websites, to cater to this platform is also a must. And presence in social media is also a must.
                        Search engine optimization (SEO) is the process of affecting the online visibility of a website or a web page in a web search engine's unpaid results—often referred to as "natural", "organic", or "earned" results. </p>
    				</div>
    				<div class="col-md-4 active wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">
    					<i class="fa fa-cloud"></i>
    					<h4>Cloud Computing</h4>
    					<p>Cloud computing is a method for delivering information technology (IT) services in which resources are retrieved from the Internet through web-based tools and applications, as opposed to a direct connection to a server. Rather than keeping files on a proprietary hard drive or local storage device, cloud-based storage makes it possible to save them to a remote database. As long as an electronic device has access to the web, it has access to the data and the software programs to run it.

                        It's called cloud computing because the information being accessed is found in "the cloud" and does not require a user to be in a specific place to gain access to it. This type of system allows employees to work remotely. Companies providing cloud services enable users to store files and applications on remote servers, and then access all the data via the internet.
                        </p>
    				</div>
    				<div class="col-md-4 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
    					<i class="fa fa-cog"></i>
    					<h4>Cyber Security Analyst</h4>
    					<p>The security analyst plays a vital role in keeping an organization’s proprietary and sensitive information secure. I works inter-departmentally to identify and correct flaws in the company’s security systems, solutions, and programs while recommending specific measures that can improve the company’s overall security posture.
                        Expose weak points and identify potential threats so that the organization can protect itself from malicious hackers. This includes penetration testing during which an analyst will test networks, computers, web-based applications, and other systems to detect exploitable vulnerabilities.
                        Expertise in cyber security, firewalls, network security, information assurance, Linux, UNIX, security information and event management (SIEM), application security, security engineering, and security architecture. They must also keep up with the latest trends in cyber security.
                        </p>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end servie -->

    	<!-- start portfolio -->
    	<section id="portfolio">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s"><span>AWESOME</span> PORTFOLIO</h2>
    				</div>
    				<div class="col-md-4 col-sm-7 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
    					   <img src="images/portfolio-1.jpg" class="img-responsive" alt="portfolio img 1">
                                <div class="portfolio-overlay">
                                    <h4>Project One</h4>
                                    <p>Using wordpress and design the overall website  of JGS Contactlens.
                                    E-Commerce website</p>
                                    <a href="http://jgscontactlens.com/" target="_blank" class="btn btn-default">VISIT SITE</a>
                                </div>
                        </div>
    				</div>

                 
    				<div class="col-md-4 col-sm-7 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-2.jpg" class="img-responsive" alt="portfolio img 2">


                                <div class="portfolio-overlay">
                                    <h4>Project Two</h4>
                                    <p><b>Royal Galkot </b> 
                                    Front end developer of Royal Galkot. Designer and Developer</p>
                                    <a href="https://royalhotel1234.000webhostapp.com/" target="_blank" class="btn btn-default">VISIT SITE</a>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-7 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-3.jpg" class="img-responsive" alt="portfolio img 3">
                                <div class="portfolio-overlay">
                                    <h4>Project Three</h4>
                                    <p><B>Welcome Event Management</B>
                                    Working as a content management and design of the project using wordpress.Designer and Developer</p>
                                    <a href="https://welcomeeventmanagement.com/" target="_blank" class="btn btn-default">VIST SITE</a>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-2 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-4.jpg" class="img-responsive" alt="portfolio img 4">
                                <div class="portfolio-overlay">
                                    <h4>Project Four</h4>
                                    <p><B>Welcome Ad Nepal</B>
                                    In Welcome Ad Nepal i work as a front end designer using wordpress.</p>
                                    <a href="https://welcomeadnepal.com/" target="_blank" class="btn btn-default">VISIT SITE</a>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-5.jpg" class="img-responsive" alt="portfolio img 3">
                                <div class="portfolio-overlay">
                                    <h4>Project Five</h4>
                                    <p><B>Susumu Internation Language Training Center</B>
                                    Language Institute where i work for the contentent management system using html and css.</p>
                                    <a href="https://sureshkhattri999.000webhostapp.com/" target="_blank" class="btn btn-default">VISIT SITE</a>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-6.jpg" class="img-responsive" alt="portfolio img 4">
                                <div class="portfolio-overlay">
                                    <h4>Care Ratings Nepal</h4>
                                    <p>Working as a web developer of Care Rating Nepal work on overall development and deployment. Using wordpress i develop this site.</p>
                                    <a href="http://careratingsnepal.com/" target="_blank" class="btn btn-default">VISIT SITE</a>
                                </div>
                        </div>
                    </div>
               <!--      <div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-7.jpg" class="img-responsive" alt="portfolio img 1">
                                <div class="portfolio-overlay">
                                    <h4>Project Seven</h4>
                                    <p><B>WeTalkTech</B>For final year project i work on CI for the WeTalkTech(an online webforum) where people can discussed according to creteria. This site in not live at.</p>
                                    <a href="#" target="_blank" class="btn btn-default"> SITE UNDER CONSTRUCTION</a>
                                </div>
                        </div>
                    </div> -->
                    <div class="col-md-4 col-sm-6 col-xs-12 wow fadeIn" data-wow-offset="50" data-wow-delay="0.6s">
                        <div class="portfolio-thumb">
                           <img src="images/portfolio-8.jpg" class="img-responsive" alt="portfolio img 2">
                                <div class="portfolio-overlay">
                                    <h4>Project Eight</h4>
                                    <p><b>ESumegh</b>Current working as a project manager of esumegh.com.
                                    This site is under construction. With this project i am involved in API's of domestic airlines of Nepal and API's  of Amadeus, Galileo and Sabre.</p>
                                    <a href="#" class="btn btn-default">SITE UNDER CONSTRUCTION</a>
                                </div>
                        </div>
                    </div>
    			</div>
    		</div>
    	</section>
    	<!-- end portfolio -->

    	<!-- start contact -->
    	<section id="contact">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-12">
    					<h2 class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">CONTACT <span>ME</span></h2>
    				</div>
    				<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-offset="50" data-wow-delay="0.9s">
    					<form action="#" method="post">
    						<label>NAME</label>
    						<input name="fullname" type="text" class="form-control" id="fullname">
   						  	
                            <label>EMAIL</label>
    						<input name="email" type="email" class="form-control" id="email">
   						  	
                            <label>MESSAGE</label>
    						<textarea name="message" rows="4" class="form-control" id="message"></textarea>
    						
                            <input type="submit" class="form-control">
    					</form>
    				</div>
    				<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInRight" data-wow-offset="50" data-wow-delay="0.6s">
    					<address>
    						<p class="address-title">MY ADDRESS</p>
    						<span>Putalisadak, Kathmandu Nepal</span>
    						<p><i class="fa fa-phone"></i> +977-9867705270</p>
    						<p><i class="fa fa-envelope-o"></i> sureshkhattri999@gmail.com</p>
    						<p><i class="fa fa-map-marker"></i> Putalisadak Kathmandu Nepal GPO 44600</p>
    					</address>
    					<ul class="social-icon">
    						<li><h4>I AM SOCIAL</h4></li>
    						<li><a href="https://www.facebook.com/profile.php?id=100010087509998" class="fa fa-facebook" target="_blank"></a></li>
                            <li><a href="https://twitter.com/SureshKhattri" class="fa fa-twitter" target="_blank"></a></li>
                            <li><a href="https://www.instagram.com/surfacedada/" class="fa fa-instagram"target="_blank"></a></li>
                            <li><a href="https://github.com/virussuresh" class="fa fa-github"target="_blank"></a></li>
                            <li><a href="https://www.linkedin.com/in/suresh-khattri-43693b140/" class="fa fa-linkedin"target="_blank"></a></li>

    					</ul>
    				</div>
    			</div>
    		</div>
    	</section>
    	<!-- end contact -->

        <!-- start copyright -->
        <footer id="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="wow bounceIn" data-wow-offset="50" data-wow-delay="0.3s">
                       	Copyright &copy; 2018 Suresh Khattri</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end copyright -->



        

	</body>
</html>